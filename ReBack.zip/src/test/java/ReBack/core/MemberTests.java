//package ReBack.core;
//
//import ReBack.core.repository.MemberRepository;
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//public class MemberTests {
//    @Test
//    public void testClass() {
//        System.out.println(MemberRepository.getClass().getmno();
//    }
//}
