package ReBack.core.data;

public enum MemberHowJoin {
    LOCAL, KAKAO
}
