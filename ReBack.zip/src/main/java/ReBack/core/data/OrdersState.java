package ReBack.core.data;

public enum OrdersState {
    REGISTR, NOTRECEIVED
}
