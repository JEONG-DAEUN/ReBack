package ReBack.core.data;

public enum LectureAvailability {
    OVER,UNDER,DEADLINE
}
