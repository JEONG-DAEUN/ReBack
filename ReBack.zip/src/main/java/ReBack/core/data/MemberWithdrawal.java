package ReBack.core.data;

public enum MemberWithdrawal {
    GENERALMEMBER,WITHDRAWAL
}
