package ReBack.core.data;

public enum Certificate {
    GTQ
}
